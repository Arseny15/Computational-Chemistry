#!/bin/sh
# Submitted using: /global/software/torque/x86_64/bin/qsub -N WebMO_381949 -S /bin/sh -o /global/software/httpd/webmo/users/47799820_chem_404_2024w1/381949/pbs_stdout -e /global/software/httpd/webmo/users/47799820_chem_404_2024w1/381949/pbs_stderr -r n -q 'abacus' -l 'nodes=1:ppn=1'

#source a sysadmin-definable externable setup script, if it exists
#this can be used to load MPI modules, setup PATHs, etc.
test -e /global/software/httpd/webmo/users/.webmo_profile && source /global/software/httpd/webmo/users/.webmo_profile

#generate a nodelist for SLURM, if applicable
if [ "pbs" = "slurm" ]; then
	export SLURM_NODEFILE=$PBS_NODEFILE
	srun -l bash -c 'hostname' | sort | awk '{print $2}' > $PBS_NODEFILE
fi

WEBMO_RSH=rsh
REMOTE_NODES=`sort -u $PBS_NODEFILE | awk '{print $1}'`
STATUS_FILE=/global/software/httpd/webmo/users/status/381949.c0id5r

umask 0022
test -d /tmp/webmo-22916 || (mkdir /tmp/webmo-22916; chmod 1777 /tmp/webmo-22916)
mkdir /tmp/webmo-22916/381949
for host in $REMOTE_NODES
do
	$WEBMO_RSH $host 'test -d /tmp/webmo-22916 || (mkdir /tmp/webmo-22916; chmod 1777 /tmp/webmo-22916)'
	$WEBMO_RSH $host mkdir /tmp/webmo-22916/381949
done

#remove the run_log if it might already exist (e.g. due to a transient error reported by qsub,
#but for some reason this script was still executed; otherwise permission issues may cause the run_log
#not to be overwritten and the job will crash!
if [ -f "/global/software/httpd/webmo/users/47799820_chem_404_2024w1/381949/run_log" ]
then
	rm /global/software/httpd/webmo/users/47799820_chem_404_2024w1/381949/run_log
fi

#make sure we cleanup, even if a crash occurs or the job is killed the the queuing systems
cleanup() {
	rm -r /tmp/webmo-22916/381949
	for host in $REMOTE_NODES
	do
		$WEBMO_RSH $host rm -r /tmp/webmo-22916/381949
	done
	
	echo "complete" >> $STATUS_FILE
}
trap cleanup EXIT

cd '/global/software/httpd/webmo/cgi-bin';
./run_gaussian.cgi 381949 47799820_chem_404_2024w1 abacus >//global/software/httpd/webmo/users/47799820_chem_404_2024w1/381949/run_log 2>&1

